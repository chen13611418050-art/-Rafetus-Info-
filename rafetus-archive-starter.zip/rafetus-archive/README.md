# Rafetus Archive Starter
A minimal template for your Rafetus website.
